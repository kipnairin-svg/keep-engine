# Putting Keep Engine on a Real URL (Render.com, free tier)

This folder is ready to upload as-is. Follow these in order.

## 1. Create a GitHub account (skip if you already have one)
Go to github.com/signup, create a free account.

## 2. Create a new repository
- Click the "+" in the top right -> "New repository"
- Name it something like `keep-engine` -> Create repository (Public or
  Private both work; Private is safer since a repo name alone doesn't
  protect the data, the password on the running app does)

## 3. Upload this folder's contents
- On the new repo's page, click "uploading an existing file"
- Drag in the two folders (`keep_engine`, `keep_ingestion_api`) and the
  `.gitignore` file from this Keep_Engine_Deploy folder, all at once
- Commit the upload (the default message is fine)

## 4. Create a Render account
Go to render.com -> Sign up, and choose "Sign up with GitHub" so it can
see your new repo without extra steps.

## 5. Create the Web Service
- Dashboard -> New -> Web Service
- Pick the `keep-engine` repo you just uploaded
- Fill in:
  - **Root Directory:** `keep_engine`
  - **Build Command:** `pip install -r requirements.txt`
  - **Start Command:** `uvicorn main:app --host 0.0.0.0 --port $PORT`
  - **Instance Type:** Free

## 6. Set your real password (important -- don't skip this)
Before or right after the first deploy, go to the service's
"Environment" tab and add two variables:
  - `KEEP_ENGINE_USER` -> pick a username (e.g. `kip`)
  - `KEEP_ENGINE_PASSWORD` -> pick a real password, not the local default
Save -- this triggers a redeploy with your real credentials in place.

## 7. Deploy
Click "Create Web Service." Render builds it (a few minutes), then gives
you a URL like `https://keep-engine-xxxx.onrender.com`. Open it, log in
with the username/password you set, and you're live.

## Honest limits of the free tier, worth knowing up front
- **It sleeps.** After about 15 minutes with no visitors, the free
  instance spins down. The next visit wakes it up again in ~30 seconds
  -- totally fine for demos and pilot calls, just don't expect it to
  feel instant if it's been idle.
- **Data isn't guaranteed to survive a restart.** The household database
  here is a local SQLite file, and Render's free tier doesn't guarantee
  that file survives a sleep/wake cycle or a redeploy. Treat this as
  great for live demos and pilot walkthroughs where you're entering data
  fresh each time, not yet as a permanent, growing client list. When
  you're ready for that, the upgrade path is a Render persistent disk
  (small paid add-on) or moving to a real hosted database -- a
  follow-up step, not something to solve today.
